Hello everyone, this is the NodeJS blog app. It provides some blogs.

How to install?
`npm i`

How to run?
`npm run dev`
